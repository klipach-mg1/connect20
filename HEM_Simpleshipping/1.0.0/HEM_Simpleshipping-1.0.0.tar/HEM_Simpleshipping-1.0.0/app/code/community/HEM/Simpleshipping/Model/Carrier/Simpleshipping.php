<?php

/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   HEM
 * @package    HEM_Simplepayment
 * @copyright  Copyright (c) 2011 Hucke EDV & Media e.K. (http://www.hucke-media.de/)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * HEM Simpleshipping Carrier Model
 *
 * @category   HEM
 * @package    HEM_Simpleshipping
 * @author     Hucke EDV & Media e.K. <magento@hucke.net>
 */
class HEM_Simpleshipping_Model_Carrier_Simpleshipping extends Mage_Shipping_Model_Carrier_Abstract
{
    protected $_code = 'simpleshipping';

    /**
     * collect shipping rates
     *
     * @param Mage_Shipping_Model_Rate_Request $request
     * @return Mage_Shipping_Model_Rate_Result
     */
    public function collectRates(Mage_Shipping_Model_Rate_Request $request)
    {
        if(!$this->getConfigFlag('active')) {
            return false;
        }

        $result = Mage::getModel('shipping/rate_result');

        $rates = $this->getRate($this->getConfigData('shippingconf'));

        foreach($rates as $rate) {
            $method = Mage::getModel('shipping/rate_result_method');

            $method->setCarrier('simpleshipping');
            $method->setCarrierTitle($this->getConfigData('title'));

            $method->setMethod('simpleshipping_' . $rate['code']);
            $method->setMethodTitle($rate['title']);

            $method->setPrice($rate['price']);
            //$method->setCost(0);

            $result->append($method);
        }

        return $result;
    }

    /**
     * return simple shipping table rates
     *
     * @param Mage_Shipping_Model_Rate_Request $data
     * @return array
     */
    public function getRate($data)
    {
        return Mage::getModel('simpleshipping/simpleshipping')->getRate($data);
    }

    /**
     * return allowed shipping methods
     *
     * @return array
     */
    public function getAllowedMethods()
    {
        $allowedMethods = array(
            'simpleshipping' => $this->getConfigData('name'),
        );

        return $allowedMethods;
    }
}
