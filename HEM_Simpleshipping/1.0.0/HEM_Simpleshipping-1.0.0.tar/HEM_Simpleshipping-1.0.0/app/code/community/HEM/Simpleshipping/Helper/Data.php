<?php

/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   HEM
 * @package    HEM_Simplepayment
 * @copyright  Copyright (c) 2011 Hucke EDV & Media e.K. (http://www.hucke-media.de/)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * HEM Simpleshipping Helper
 *
 * @category   HEM
 * @package    HEM_Simpleshipping
 * @author     Hucke EDV & Media e.K. <magento@hucke.net>
 */

class HEM_Simpleshipping_Helper_Data extends Mage_Core_Helper_Abstract
{
}