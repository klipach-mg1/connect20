<?php

/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   HEM
 * @package    HEM_Simplepayment
 * @copyright  Copyright (c) 2011 Hucke EDV & Media e.K. (http://www.hucke-media.de/)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * HEM Simpleshipping Model
 *
 * @category   HEM
 * @package    HEM_Simpleshipping
 * @author     Hucke EDV & Media e.K. <magento@hucke.net>
 */
class HEM_Simpleshipping_Model_Simpleshipping extends Mage_Core_Model_Abstract
{
    const _field_CODE = 0;
    const _field_PRICE = 1;
    const _field_DESCRIPTION = 2;

    /**
     * return simple shipping table rates
     *
     * @param Mage_Shipping_Model_Rate_Request $data
     * @return array
     */
    public function getRate($data)
    {
        $rates = array();
        $methods = explode("\n", $data);

        foreach($methods as $method) {
            $method = trim($method);
            $method = explode('|', $method);

            $code = trim($method[self::_field_CODE]);
            $price = (float) trim($method[self::_field_PRICE]);
            $title = trim($method[self::_field_DESCRIPTION]);

            $title = str_replace(array('=>', '<='), array('<strong>', '</strong>'), $title);

            $baseCurrencyCode = Mage::app()->getStore()->getBaseCurrencyCode();
            $currentCurrencyCode = Mage::app()->getStore()->getCurrentCurrencyCode();

            if ($price != 0) {
                $price = $price * $price / Mage::helper('directory')->currencyConvert($price, $baseCurrencyCode, $currentCurrencyCode);
            }

            $rates[] = array(
                'code' => $code,
                'title' => $title,
                'price' => $price,
            );
        }
        krsort($rates);

        return $rates;
    }
}
